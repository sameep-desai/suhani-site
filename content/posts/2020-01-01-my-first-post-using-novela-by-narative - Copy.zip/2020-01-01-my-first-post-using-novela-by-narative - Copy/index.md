---
title: RCC Structural Work
author: Dennis Brotzky
date: 2020-04-30
hero: ./images/rcc-structure.jpg
excerpt: We follow best practices with regard to foundation, excavation and earthwork, quality of cement and proper curing while carrying out the RCC structural work.
---

## Quality materials & craftsmanship

We follow best practices with regard to foundation, excavation and earthwork, quality of cement and proper curing while carrying out the RCC structural work. Only quality materials, craftsmanship and diligent care to every detail can ensures a structure to stand tall and thrive for more than a lifetime. At Suhani we ensure that it does.


